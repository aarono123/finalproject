﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

using Microsoft.WindowsAzure.MobileServices;
using System.Threading.Tasks;
using Windows.UI.Popups;
using Windows.Storage;
using System.Net.Http;
using Newtonsoft.Json;

using Amazon.IdentityManagement;
using Amazon.IdentityManagement.Model;

using Microsoft.WindowsAzure;
//using Microsoft.WindowsAzure.MobileServices;
/*using Windows.UI.Popups;
using System.Threading.Tasks;*/

public class ToDoItem
{
    public string ID { get; set; }
    public string Text { get; set; }
    public string TITLE { get; set; }
    public string AUTHOR { get; set; }
    public string PRICE { get; set; }
    public Boolean _deleted { get; set; }
}

//private MobileServiceCollection<ToDoItem, ToDoItem> items;
//private IMobileServiceTable<ToDoItem> todoTable = App.cop4777cNewBrook2Client.GetTable<ToDoItem>();

/*private async void InsertRecord(string strInput)
{
    try
    {

        ToDoItem item = new ToDoItem { Text = strInput, TITLE = "Awesome item", AUTHOR = "John Doe", PRICE = "$50.00" };
        await App.MobileService.GetTable<ToDoItem>().InsertAsync(item);

        //using Windows.UI.Popups;
        MessageDialog messageDialog = new MessageDialog("Completed Successfully!", "Windows 8");
        await messageDialog.ShowAsync();

    }
    catch (Exception e)
    {
        MessageDialog messageDialog = new MessageDialog("An Error Occurred: " + e.Message, "Windows 8");
        await messageDialog.ShowAsync();
    }
}*/












/*private void button_Click(object sender, RoutedEventArgs e)
{
    InsertRecord(txtBoxInput.Text);
}*/


// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace App2

{
    namespace Course.ViewModels
    {
        public class CourseViewModel
        {
            public String course1 { get; set; }
            public String course2 { get; set; }
            public String course3 { get; set; }
            public String course4 { get; set; }
            public String course5 { get; set; }
            public String course6 { get; set; }
            public String course7 { get; set; }
            public String course8 { get; set; }
            public String course9 { get; set; }

            public String Desc1 { get; set; }
            public String Desc2 { get; set; }
            public String Desc3 { get; set; }
            public String Desc4 { get; set; }
            public String Desc5 { get; set; }
            public String Desc6 { get; set; }
            public String Desc7 { get; set; }
            public String Desc8 { get; set; }
            public String Desc9 { get; set; }

            public CourseViewModel()
            {
                //List of course numbers for the  Catalog
                string[] courseNumbers = new string[9] { "COP3488C", "CIS3801C", "CDA3315C","Coming Soon","COP4474C","MAN3504","CDA3428C","CIS3801C","CIS4655C" };

                //List of course Titles from the Catalog
                string[] courseNames = new string[9] { "Universal Windows Applications Programming I", "Fundamentals of Mobile Web Application Development",
                                                        "Fundamentals of Enterprise Architecture","Coming Soon","Universal Windows Applications Programming II","Operations Management","Fundamentals of Distributed Application Architecture","Fundamentals of Mobile Web Application Development",
                                                        "Advanced Mobile Web Application Development",

                };

                //List of course Descriptions from the Catalog
                string[] courseDescriptions = new string[9] { "This course provides students an introduction to the basic features of the Microsoft C# programming language as it applies to Universal Windows Application mobile application development. Students will review the history, features, and advantages of the C# programming language, utilize the Visual Studio programming environment, demonstrate a mastery of C# programming basics, and develop a basic Universal Windows Application. Prerequisite:Enterprise Architecture, Distributed Application Architecture",
                                                              "This course presents the fundamentals of mobile web applications development. It places a focus on implementing well-defined mobile application standards, while designing a mobile application as a business solution to a real business scenario. Topics include mobile application standards, selecting appropriate content adaptation strategies, and following the system's development life cycle to plan, design, test, and deploy a mobile application. This course will prepare students to develop a professional mobile application that meets today’s business standards. Prerequisite:None",
                                                              "This course is the study of business enterprise analysis, design, planning and implementation. It places focus on working with stakeholders, modeling business data flows and interfaces, determining the information security risk for an organization, and re-engineering business processes. Topics include current software development methodologies, business process modeling, and enterprise information security methodologies. This course will prepare students to work with stakeholders to ensure that information technology is in alignment with the goals of the business. Prerequisite: None","Coming Soon",
                                                               "This course presents advanced application design and Microsoft C# programming techniques related to Universal Windows Application development. Students will analyze user interface design and the Windows features that support it, demonstrate a mastery of Microsoft user interface tools, construct a C# database application, and develop a basic C# mobile application that accesses Microsoft Azure.",
                                                               "In this course students examine the operations function of managing people, information, technology, materials, and facilities to produce goods and services. Specific areas covered will include: designing and managing operations; purchasing raw materials; controlling and maintaining inventories; and producing good or services that meet customers' expectations. Quantitative modeling will be used for solving business problems.","This course is the study of the design and use of distributed software applications as part of a enterprise architecture in a typical business. It places focus on the software development process, business process analysis, and generating functional requirements for business technology. Topics include software architecture, business process analysis, agile development, and scalability. This course will prepare students for producing a software development project plan, documenting hardware and software requirements to support current and future transaction loads, and modeling end-to-end data flows for a given business process.",
                                                               "This course presents the fundamentals of mobile web applications development. It places a focus on implementing well-defined mobile application standards, while designing a mobile application as a business solution to a real business scenario. Topics include mobile application standards, selecting appropriate content adaptation strategies, and following the system's development life cycle to plan, design, test, and deploy a mobile application. This course will prepare students to develop a professional mobile application that meets today’s business standards.", "This course is the study of advanced mobile application development. It places a detailed focus on building a mobile application user interface, planning and designing database models, and deploying mobile applications to emulators, as well as popular mobile application stores. Topics include designing a professional graphical prototype of the user interface, designing navigation that meets usability requirements, constructing data models and databases, interfacing code to databases, and testing then deploying an application to popular application stores. This course will prepare students to create more advanced mobile applications that interact with cloud-based databases.",



                                                              };
                //Adds course numbers with course names for each list item to display on each button.
                course1 = courseNumbers[0] + ": " + courseNames[0];
                course2 = courseNumbers[1] + ": " + courseNames[1];
                course3 = courseNumbers[2] + ": " + courseNames[2];
                course4 = courseNumbers[3] + ": " + courseNames[3];
                course5 = courseNumbers[4] + ": " + courseNames[4];
                course6 = courseNumbers[5] + ": " + courseNames[5];
                course7 = courseNumbers[6] + ": " + courseNames[6];
                course8 = courseNumbers[7] + ": " + courseNames[7];
                course9 = courseNumbers[8] + ": " + courseNames[8];


                //Assigns course description list items to variables
                Desc1 = courseDescriptions[0];
                Desc2 = courseDescriptions[1];
                Desc3 = courseDescriptions[2];
                Desc4 = courseDescriptions[3];
                Desc5 = courseDescriptions[4];
                Desc6 = courseDescriptions[5];
                Desc7 = courseDescriptions[6];
                Desc8 = courseDescriptions[7];
                Desc9 = courseDescriptions[8];

            }
        }
    }

    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();


        }


        private void button1_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(App2.GoogleAuth));
        }


 


        private void btnRas_Click(object sender, RoutedEventArgs e)
        {

        }


        public static string AWS_Name { get; set; }

        public static void GetAWS()
        {
            var Var2 = new Amazon.Auth.AccessControlPolicy.Policy();
            AWS_Name = Convert.ToString(Var2.Version);
        }

        private void btnGetAPI_Click(object sender, RoutedEventArgs e)
        {
            GetAWS();
        }

        
    
        IMobileServiceTable<TodoItem> todoTable = App.MobileService.GetTable<TodoItem>();
        MobileServiceCollection<TodoItem, TodoItem> items;

        public class Contact
        {
            public int ID { get; set; }
            public string NAME { get; set; }
            public string EMAILADDRESS { get; set; }
        }


        public class TodoItem
        {
            public string Id { get; set; }
            public string Text { get; set; }
            public bool Complete { get; set; }
        }

        async private void Submit_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                TodoItem item = new TodoItem
                {
                    Text = txtBoxItem.Text,
                    Complete = false
                };
                await App.MobileService.GetTable<TodoItem>().InsertAsync(item);
                var dialog = new MessageDialog("Successful!");
                await dialog.ShowAsync();
            }
            catch (Exception em)
            {
                var dialog = new MessageDialog("An Error Occured: " + em.Message);
                await dialog.ShowAsync();
            }
        }

        public void GetDBSync()
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new
                    Uri("https://cis4655c-webapp1.azurewebsites.net");

                var json = client.GetStringAsync("/").Result;
                var contacts = JsonConvert.DeserializeObject<Contact[]>(json);
            }
        }


        private async Task RefreshTodoItems()
        {
            MobileServiceInvalidOperationException exception = null;
            try
            {
                // This code refreshes the entries in the list view by querying the TodoItems table.
                // The query excludes completed TodoItems
                items = await todoTable
                    .Where(TodoItem => TodoItem.Complete == false)
                    .ToCollectionAsync();
            }
            catch (MobileServiceInvalidOperationException e)
            {
                exception = e;
            }

            if (exception != null)
            {
                await new MessageDialog(exception.Message, "Error loading items").ShowAsync();
            }
            else
            {
                ListItems.ItemsSource = items;
                this.btnRefresh.IsEnabled = true;
            }
        }

        private async void CheckBoxComplete_Checked(object sender, RoutedEventArgs e)
        {
            CheckBox cb = (CheckBox)sender;
            TodoItem item = cb.DataContext as TodoItem;
            await UpdateCheckedTodoItem(item);
        }

        private async Task UpdateCheckedTodoItem(TodoItem item)
        {
            // This code takes a freshly completed TodoItem and updates the database. When the MobileService 
            // responds, the item is removed from the list 
            await todoTable.UpdateAsync(item);
            items.Remove(item);
            ListItems.Focus(Windows.UI.Xaml.FocusState.Unfocused);

            //await SyncAsync(); // offline sync
        }

        async private void btnRefresh_Click_1(object sender, RoutedEventArgs e)
        {
            await RefreshTodoItems();
        }


        private void button_Click(object sender, RoutedEventArgs e)
        {
            string[] Dataobject = new string[]
            {
            "COP3488C Section 01", "Universal Windows Applications Programming", "G380/AMH3304 Section 03","Visions Of America Since 1945"
            };
        }

        private void textBox1_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(App2.Pages.Faculty));
        }

        /*private void button1_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(App2.Pages.Calculator));
        }*/

        private void CourseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(App2.Pages.CoursePage));
        }
        private void UserAuthbutton_click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(App2.Pages.UserAuth));
        }
        
            
        
    }

}
