﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace App2.Pages
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class CoursePage : Page
    {
        public CoursePage()
        {
            this.InitializeComponent();
        }

        private void courseButton1_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(App2.Pages.Course1));
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(UserAuth));
        }

        private void coursebutton2_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(App2.Pages.Course2));
        }

        private void coursebutton3_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(App2.Pages.Course3));
        }

        private void coursebutton4_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(App2.Pages.Course4));
        }

        private void coursebutton5_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(App2.Pages.Course5));
        }

        private void coursebutton6_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(App2.Pages.Course7));
        }

        private void coursebutton7_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(App2.Pages.Course8));
        }

        private void coursebutton8_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(App2.Pages.Course9));
        }

        private void Nextbutton_click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(App2.Pages.UserAuth));
        }
    }

}
