﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App2
{
    public class FacultyCred
    {
        public String Faculty1 { get; set; }
        public String Faculty2 { get; set; }
        public String Faculty3 { get; set; }
        public String Faculty4 { get; set; }
        public String Faculty5 { get; set; }


        public String FacultyDesc1 { get; set; }
        public String FacultyDesc2 { get; set; }
        public String FacultyDesc3 { get; set; }
        public String FacultyDesc4 { get; set; }
        public String FacultyDesc5 { get; set; }



        public FacultyCred()
        {
            //List of Faculty Names from Programs
            string[] FacultyNames = new string[5] { "Jennifer Moorhead", "Sherry Kamrowski", "Charli Weatherford","Kirk Olson", "Rebecca Sims" };

            //List of Faculty schools they are apart of
            string[] FacultyPro = new string[5] { "School of Business","School of Business", "School of Heath Sciences","School of Design", "School of Justice Studies", };

            //List of Faculty descriptions
            string[] FacultyDescription = new string[5] { "Jennifer Moorhead is a full - time instructor with the School of Business and teaches Internet Marketing, e - Commerce, Principles of Marketing, Advertising, Marketing Ethics, and Introduction to Business.A seasoned professional within the business world, Jennifer has more than 17 years of experience working on both the client and agency side of developing successful branding and strategic marketing plans. While employed with SunGard HTE, Jennifer gained first-hand experience and was an integral part of strategic planning and implementation of numerous marketing plans that targeted local government and public safety agencies. While working at a local marketing boutique, Jennifer worked with several web-based clients to develop marketing strategies and execution plans, as well as budgets, brand and campaign messaging, and market positioning through the use of both online and offline marketing tools and tactics. Jennifer believes her work experience helps her prepare students for scenarios and challenges that they will encounter in a typical business environment, and how to successfully navigate those scenarios. Jennifer earned a B.S. in Business Administration with an emphasis in Marketing from the University of Central Florida and an MBA from the University of Central Florida.",
                "Sherry Kamrowski has been teaching at Rasmussen College for more than 23 years and is a full-time instructor with the School of Business teaching Microsoft Office Programs. Prior to teaching at Rasmussen College, Sherry taught at Winona State University, managed office personnel and logistics at Universal Title, and a Loan Processor at Meritor Mortgage, where she was recognized for approving and closing more than one million dollars in loans. Sherry believes her work experience helps her relay to her students the importance of critical thinking in all situations, particularly challenging situations that require creative problem solving.Throughout her career at Rasmussen College, Sherry served on the Learning and Teaching Committee, Assessment Committee, Technology Committee, and many others in an effort to help meet our progressive education and institution goals.Sherry earned a B.S. in Business Education from Winona State University and she is currently working toward a Master of Divinity with an emphasis in marriage and family therapy at Bethel Seminary, Bethel University.",
                "Charli Weatherford is a full-time instructor with the School of Technology and Design and teaches Introduction to Computer Graphics, Digital Production, and Typography. Having received her M.S. degree online, Charli is a strong believer in online education and the benefits it affords working students or students with family obligations. She has been with Rasmussen College since 2004, but she has been teaching digital design courses at the college level since 1998 when she was an instructor at Full Sail University. With over 14 years of industry experience in the digital design field, Charli also serves as a subject matter expert for several of the courses in our School of Technology and School of Design. Charli also served as the Dean of Rasmussen College Online from 2006 – 2008. She currently trains new online faculty, in addition to her teaching course load.Charli earned a B.S. in Theatre and Speech from Newberry College, an M.S. in Education with a specialization in Management & Administration of Educational Programs and a Certificate in Distance Learning Leadership from Nova Southeastern University.",
                "Kirk Olson is a full-time instructor with the School of Justice Studies. After graduating from law school, Kirk led a successful career as a solo practitioner at his private practice firm for more than 25 years. With years of experience in myriad legal cases, from criminal to civil, Kirk has learned to navigate the legal system and is eager to pass along this knowledge to his students. Kirk has tried several cases, both bench and jury trials, and he has seen both the winning and losing end of the legal system. He has a thorough understanding of the law; its interpretations in state, federal, and appellate courts; and the effect it can have on clients with and without solid cases. Kirk is a strong believer in the U.S. justice system, and he enjoys sharing its intricacies with his students. Kirk is an active member of his community and is a constant fixture in the nonprofit organizations and charities in his hometown as he helps them achieve their goals. Kirk earned a B.A. in Political Science from the University of Minnesota and a J.D. from the University of Minnesota.",
                "Rebecca Sims is a full-time instructor with Rasmussen College and teaches Foundations of English II, Success Strategies, and Professional Communications. Rebecca joined Rasmussen College in 2007. Prior to becoming an instructor at Rasmussen College, she taught English at the high school level in Texas and Indiana. Rebecca’s passion for helping students gain a deeper understanding of the English language continues to motivate her each day. She understands that English is a complex language and thoroughly enjoys watching her students further their knowledge in this area and gain the confidence in their use of it. Rebecca earned a B.A. in English Literature from DePauw University and a Master’s in Education from the University of California.",






            };



            //Adds FacultyNames and Schools together
            Faculty1 = FacultyNames[0] + ": " + FacultyPro[0];
            Faculty2 = FacultyNames[1] + ": " + FacultyPro[1];
            Faculty3 = FacultyNames[2] + ": " + FacultyPro[2];
            Faculty4 = FacultyNames[3] + ": " + FacultyPro[3];
            Faculty5 = FacultyNames[4] + ": " + FacultyPro[4];

            //Shows the FacultyDesc
            FacultyDesc1 = FacultyDescription[0];
            FacultyDesc2 = FacultyDescription[1];
            FacultyDesc3 = FacultyDescription[2];
            FacultyDesc4 = FacultyDescription[3];
            FacultyDesc5 = FacultyDescription[4];
        }
        }
}
