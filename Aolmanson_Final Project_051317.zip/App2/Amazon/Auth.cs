﻿namespace Amazon
{
    internal class Auth
    {
        internal class AccessControlPolicy
        {
            internal class Policy
            {
                public Policy()
                {
                }

                public bool Version { get; internal set; }
            }
        }
    }
}