﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App2
{
    
    
        public class CourseCredits
        {
            public String course1 { get; set; }
            public String course2 { get; set; }
            public String course3 { get; set; }
            public String course4 { get; set; }
            public String course5 { get; set; }
            public String course6 { get; set; }
            public String course7 { get; set; }
            public String course8 { get; set; }
            public String course9 { get; set; }

            public String UserAuth { get; set; }


            public CourseCredits()
            {
                //List of course numbers for the  Catalog
                string[] courseCredits = new string[9] { "Credits: 4", "Credits: 4", "Credits: 4","Comning Soon","Credits: 4","Credits: 4","Credits: 4","Credits: 4","Credits: 4" };

                //List of course Titles from the Catalog
                string[] coursePrereq = new string[9] { "Prerequisite: None", "Prerequisite: None",
                                                        "Prerequisite: None","Coming Soon","Prerequisite: Universal Windows Applications Programming I",
                                                        "Prerequisite: None","Prerequisite: None","Prerequisite: None","Prerequisite: Fundamentals of Mobile Web Applications Development",};


                //Adds course numbers with course names for each list item to display on each button.
                course1 = courseCredits[0] + ": " + coursePrereq[0];
                course2 = courseCredits[1] + ": " + coursePrereq[1];
                course3 = courseCredits[2] + ": " + coursePrereq[2];
                course4 = courseCredits[3] + ": " + coursePrereq[3];
                course5 = courseCredits[4] + ": " + coursePrereq[4];
                course6 = courseCredits[5] + ": " + coursePrereq[5];
                course7 = courseCredits[6] + ": " + coursePrereq[6];
                course8 = courseCredits[7] + ": " + coursePrereq[7];
                course9 = courseCredits[8] + ": " + coursePrereq[8];


        }
        }
    }

